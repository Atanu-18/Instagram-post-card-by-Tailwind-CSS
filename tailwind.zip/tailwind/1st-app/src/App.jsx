import React from 'react'

function App() {
  return (
    <div className='flex items-center justify-center min-h-screen'>
      <div className='h-[550px] w-[650px] border border-b-slate-400 items-center justify-center bg-stone-200 rounded-xl'>
      <div className='flex justify-between'>
        <div className='flex gap-1.5'>
        <img src="image/pro.jpg" alt="profile_pic" className='h-[50px] w-[50px] rounded-full mt-2 ml-3.5 cursor-pointer' />
        <h1 className='font-bold mt-5 cursor-pointer'>Atanu Mandal</h1>
        </div>
        <i class="fa-solid fa-ellipsis-vertical mt-6 mr-5 text-2xl"></i>
      </div>

      <img src="image/cat1.jpg" alt="body_pic" className='h-[310px] w-[625px] m-3 rounded-2xl'/>

      <div className='flex gap-3 m-3 text-2xl cursor-pointer'>
      <i class="fa-solid fa-heart"></i>
      <i class="fa-solid fa-comment"></i>
      <i class="fa-solid fa-share"></i>
      </div>

      <div className='ml-3'>
        <h3 className='font-bold'>52 likes <span>·</span> 6 comments</h3>
        <h2 className='font-bold'>Atanu Mandal <span className='font-normal'>Sleeping &#128564;</span></h2>
      </div>

      <h2 className='font-bold text-slate-600 ml-3 mt-6'>View all 6 comments</h2>
    </div>
    </div>
  )
}

export default App